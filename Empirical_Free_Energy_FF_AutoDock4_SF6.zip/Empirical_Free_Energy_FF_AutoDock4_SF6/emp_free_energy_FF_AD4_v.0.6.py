# Program to calculate intermolecular potential based on atomic coordinates in the PDBQT format
# It uses pair-wise energetic terms of the AutoDock4 progam (Morris et al., 1998).
# 
# Walter F. de Azevedo Jr.
# October 3, 2018
# azevedolab.net
#
# Reference:
# Morris G, Goodsell D, Halliday R, Huey R, Hart W, Belew R, Olson A. Automated docking using a
# Lamarckian genetic algorithm and an empirical binding free energy function. J Comput Chem. 1998; # 19:1639-1662. 

# Define InterMol() class
class InterMol(object):
    """Class to calculate intermolecular potential based on AutoDock4 pair-wise energetic terms"""
    
    # Define constructor method
    def __init__(self,ad4_par_file):
        """Constructor method"""
        
        # Set up attributes
        self.ad4_par_file = ad4_par_file    # AutoDock4 parameter file
        
    # Define read_AD4_bound() method
    def read_AD4_bound(self):
        """Method to read AD4.1_bound.data file and return a list"""
        
        # Set up empty list
        self.ad4_list = []
        
        # Try to open self.ad4_par_file
        try:
            fo1 = open(self.ad4_par_file,"r")
        except IOError:
            print("\n I can't find ",self.ad4_par_file," file.")
            return
            
        # Looping through fo1
        for line in fo1:
            if line[0:8] == "atom_par":
                # print(line)
                self.ad4_list.append(line)
        
        # Close file
        fo1.close()
        
        # Return list
        return self.ad4_list
        
    # Define get_atom_par_LJ()
    def get_atom_par_LJ(self,par,atom_i,atom_j):
        """Method to retrieve LJ parameters for each atom pair"""
        
        # Looping through par
        for line in par:
            if line[9:11] == atom_i:
                reqm_i = float(line[16:20])     # Equilibrium internuclear distance in Angstrom
                epsilon_i = float(line[21:27])  # Well depth at reqm in Kcal/mol
            elif line[9:11] == atom_j:
                reqm_j = float(line[16:20])     # Equilibrium internuclear distance in Angstrom
                epsilon_j = float(line[21:27])  # Well depth at reqm in Kcal/mol
        
        # Return results
        return reqm_i,epsilon_i,reqm_j,epsilon_j 
        
    # Define get_atom_par_HB()
    def get_atom_par_HB(self,par,atom_i,atom_j):
        """Method to retrieve HB parameters for each atom pair"""
        
        # Looping through par
        for line in par:
            if line[9:11] == atom_i:
                reqm_i = float(line[46:51])     # Equilibrium internuclear distance in Angstrom
                epsilon_i = float(line[51:56])  # Well depth at reqm in Kcal/mol
            elif line[9:11] == atom_j:
                reqm_j = float(line[46:51])     # Equilibrium internuclear distance in Angstrom
                epsilon_j = float(line[51:56])  # Well depth at reqm in Kcal/mol
        
        # Return results
        try:
            return reqm_i,epsilon_i,reqm_j,epsilon_j  
        except:
            if atom_j == "HD":
                reqm_j,epsilon_j = 0.0,0.0
            elif atom_j == "N ":
                reqm_j,epsilon_j = 0.0,0.0
            elif atom_j == "OA":
                reqm_j,epsilon_j = 1.9,5.0
            elif atom_j == "NA":
                reqm_j,epsilon_j = 1.9,5.0
            elif atom_j == "C ":
                reqm_j,epsilon_j = 0.0,0.0
            elif atom_j == "A ":
                reqm_j,epsilon_j = 0.0,0.0
            else:
                print("\nProblems with atoms ",atom_i,atom_j)
            return reqm_i,epsilon_i,reqm_j,epsilon_j
            
    
    # Define get_atom_par_Sol()
    def get_atom_par_Sol(self,par,atom_i,atom_j):
        """Method to retrieve solvent parameters for each atom pair"""
        
        # Looping through par
        for line in par:
            if line[9:11] == atom_i:
                vol_i = float(line[27:36])      # Atomic solvation volume (in Angstrom^3)
                sol_i = float(line[36:46])      # Atomic solvation parameter
            elif line[9:11] == atom_j:
                vol_j = float(line[27:36])      # Atomic solvation volume (in Angstrom^3)
                sol_j = float(line[36:46])      # Atomic solvation parameter
        
        # Return results
        try:
            return vol_i,sol_i,vol_j,sol_j 
        except:
            if atom_j == "HD":
                vol_j,sol_j = 0.0000,0.00051
            elif atom_j == "N ":
                vol_j,sol_j = 22.4493,-0.00162
            elif atom_j == "OA":
                  vol_j,sol_j = 17.1573,-0.00251
            elif atom_j == "C ":
                  vol_j,sol_j = 33.5103,-0.00143
            elif atom_j == "NA":
                  vol_j,sol_j = 22.4493,-0.00162
            elif atom_j == "A ":
                  vol_j,sol_j = 33.5103,-0.00052
            else:
                print("\nProblems with atom ",atom_j)
                
            return vol_i,sol_i,vol_j,sol_j
        
    # Define dist() method
    def dist(self,x1,y1,z1,x2,y2,z2):
        """Method to calculate Euclidian distance"""
        
        # Import library
        import numpy as np
        
        # Calculate Euclidian distance
        d = np.sqrt((x1-x2)**2 + (y1-y2)**2 + (z1-z2)**2)

        # Return distance
        return d
        
    # Define intermol_pot_LJ() method
    def intermol_pot_LJ(self,par_in,ligand,receptor,n,m):
        """Method to calculate intermolecular LJ potential"""
        
        # Import library
        import vdw6 as vd
                
        # Assign zero to v_r
        v_r = 0
        
        # Looping through ligand atoms
        for line_i in ligand:
            
            # Looping through receptor atoms
            for line_j in receptor:
                
                # Get atom type
                atom_i = line_i[77:79]
                atom_j = line_j[77:79]
                
                # Get atomic coordinate for i atom
                x_i = float(line_i[30:38])
                y_i = float(line_i[38:46])
                z_i = float(line_i[46:54])
                
                # Get atomic coordinate for j atom
                x_j = float(line_j[30:38])
                y_j = float(line_j[38:46])
                z_j = float(line_j[46:54])
                
                # Invoking dist() method
                r = self.dist(x_i,y_i,z_i,x_j,y_j,z_j)
                
                # Instantiating an object of the PairwisePot() class and assign it to LJ
                LJ = vd.PairwisePot()
                
                # reqm_i and reqm_j = equilibrium internuclear distance in Angstrom
                # epsilon_i and epsilon_j = well depth at reqm in Kcal/mol 
                
                # Avoid some problems with pdbqt file
                try:
                    reqm_i,epsilon_i,reqm_j,epsilon_j=self.get_atom_par_LJ(par_in,atom_i,atom_j)

                except:
                    if atom_i == "A " and atom_j == "A ":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 4.0,0.15,4.0,0.15
                    elif atom_i == "NA" and atom_j == "NA":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 3.5,0.16,3.5,0.16
                    elif atom_i == "N " and atom_j == "N ":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 3.5,0.16,3.5,0.16
                    elif atom_i == "HD" and atom_j == "HD":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 2.0,0.02,2.0,0.02
                    elif atom_i == "OA" and atom_j == "OA":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 3.2,0.2,3.2,0.2
                    elif atom_i == "OA" and atom_j == "C ":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 3.2,0.2,4.0,0.15
                    elif atom_i == "C " and atom_j == "C ":
                        reqm_i,epsilon_i,reqm_j,epsilon_j = 4.0,0.15,4.0,0.15
                    else:
                        print(atom_i,atom_j)
                    
                # Invoking potential() method using above data as arguments
                cn,cm,v = LJ.potential(reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n)
                
                # Calculate potential for all atoms
                v_r += v
                
        # Return result
        return v_r
                 
    # Define intermol_pot_HB() method
    def intermol_pot_HB(self,par_in,ligand,receptor,n,m):
        """Method to calcular intermolecular potential"""
        
        # Import library
        import hb6 as hb
        
        # Assign zero to v_r
        v_r = 0
        
        # Looping through ligand atoms
        for line_i in ligand:
            
            # Looping through receptor atoms
            for line_j in receptor:
                
                # Get atom type
                atom_i = line_i[77:79]
                atom_j = line_j[77:79]
                
                # Get atomic coordinate for i atom
                x_i = float(line_i[30:38])
                y_i = float(line_i[38:46])
                z_i = float(line_i[46:54])
                
                # Get atomic coordinate for j atom
                x_j = float(line_j[30:38])
                y_j = float(line_j[38:46])
                z_j = float(line_j[46:54])
                
                # Invoking dist() method
                r = self.dist(x_i,y_i,z_i,x_j,y_j,z_j)
                
                # Instantiating an object of the PairwisePotHB() class and assign it to LJ
                HB1 = hb.PairwisePotHB()
                
                # reqm_i and reqm_j = equilibrium internuclear distance in Angstrom
                # epsilon_i and epsilon_j = well depth at reqm in Kcal/mol 
                # Invoking get_atom_par_HB() method             
                reqm_i,epsilon_i,reqm_j,epsilon_j = self.get_atom_par_HB(par_in,atom_i,atom_j)

                # Invoking potential() method using above data as arguments
                cn,cm,v = HB1.potential(reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n)
                
                # Calculate potential for all atoms
                v_r += v
                        
        # Return result
        return v_r
    
    # Define intermol_pot_Sol() method
    def intermol_pot_Sol(self,par_in,ligand,receptor,n,m):
        """Method to calcular intermolecular potential"""
        
        # Import library
        import solv6 as s1
                        
        # Assign zero to v_r
        v_r = 0
        
        # Looping through ligand atoms
        for line_i in ligand:
            
            # Looping through receptor atoms
            for line_j in receptor:
                
                # Get atom type
                atom_i = line_i[77:79]
                atom_j = line_j[77:79]
                
                # Get atomic coordinate for i atom
                x_i = float(line_i[30:38])
                y_i = float(line_i[38:46])
                z_i = float(line_i[46:54])
                
                # Get atomic coordinate for j atom
                x_j = float(line_j[30:38])
                y_j = float(line_j[38:46])
                z_j = float(line_j[46:54])
                
                # Invoking dist() method
                r = self.dist(x_i,y_i,z_i,x_j,y_j,z_j)
                
                # Instantiating an object of the PairwisePotHB() class and assign it to LJ
                Sol1 = s1.PairwisePotSol()
                                
                # reqm_i and reqm_j = equilibrium internuclear distance in Angstrom
                # epsilon_i and epsilon_j = well depth at reqm in Kcal/mol 
                
                # Get parameters
                vol_i,sol_i,vol_j,sol_j = self.get_atom_par_Sol(par_in,atom_i,atom_j)
                    
                # Invoking potential() method using above data as arguments
                v = Sol1.potential(vol_i,sol_i,vol_j,sol_j,r,m,n)
                
                # Calculate potential for all atoms
                v_r += v
                
        # Return result
        return v_r
    
    # Define read_PDBQT() method
    def read_PDBQT(self,file_in):
        """Method to read PDBQT file"""
        
        # Set up empty for atom lines
        atom_list = []
        
        # Try to open PDBQT file
        try:
            fo1 = open(file_in,"r")
        except IOError:
            print("\nI can't find ",file_in," file.")
            return atom_list
            
        # Looping through fo1
        for line in fo1:
            if line[0:6] == "HETATM" or line[0:6] == "ATOM  ":
                atom_list.append(line)
        
        # Close file
        fo1.close()
        
        # Return results
        return atom_list
    
    # Define epsilon0() method
    def epsilon0(self,r):
        """Method to calcule sigmoidal distance-dependent dielectric function """
        
        # Import library
        import numpy as np
        
        # Set up constants (taken from http://autodock.scripps.edu/faqs-help/manual/autodock-3-user-s-guide/AutoDock3.0.5_UserGuide.pdf)
        A = -8.5525     
        l = 0.003627
        k = 7.7839
        e0 = 78.4       # Dielectric constant of bulk water at 25˚C
        B = e0 - A
        
        # A sigmoidal distance-dependent dielectric function is used to model solvent 
        # screening,based on the work of Mehler and Solmajer.
        # Mehler, E.L. and Solmajer, T. (1991) “Electrostatic effects in proteins: comparison of 
        # dielectric and charge models” Protein Engineering, 4, 903-910.
        e0_r = A + B/(1+k*np.exp(-l*B*r))
        
        # Return result
        return e0_r
         
    # Define intermol_electro() method
    def intermol_electro(self,ligand,receptor):
        """Method to calculate intermolecular electrostatic potential"""
        
        # Assign zero to v_r
        v_r = 0
        
        # Looping through ligand atoms
        for line_i in ligand:
            
            # Looping through receptor atoms
            for line_j in receptor:
                
                # Get atom type
                atom_i = line_i[77:79]
                atom_j = line_j[77:79]
                
                # Get atomic coordinate for i atom
                x_i = float(line_i[30:38])
                y_i = float(line_i[38:46])
                z_i = float(line_i[46:54])
                q_i = float(line_i[66:75])
                
                # Get atomic coordinate for j atom
                x_j = float(line_j[30:38])
                y_j = float(line_j[38:46])
                z_j = float(line_j[46:54])
                q_j = float(line_j[66:75])
                
                # Invoking dist() method
                r = self.dist(x_i,y_i,z_i,x_j,y_j,z_j)
                
                v = q_i*q_j/(r*self.epsilon0(r)) 
                
                # Calculate potential for all atoms
                v_r += v
                
        # Return result
        return v_r

    # Define plot_it() method
    def plot_pot(self,type_pot,x_label,y_label,r_min,r_max,reqm_i,epsilon_i,reqm_j,epsilon_j,m,n):
        """Method to generate plot for intermolecular potential functions"""
        
        # Import libraries
        import numpy as np
        import matplotlib.pyplot as plt
        
        
        r = np.arange(r_min,r_max, 0.01)
        
        # Check type of potential to plot
        if type_pot == "LJ":
            # Import specific library
            import vdw6 as vd
            
            # Instantiating an object of the PairwisePot() class and assign it to LJ
            LJ = vd.PairwisePot()
            
            # Invoking potential() method using above data as arguments
            _,_,v = LJ.potential(reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n)
            
            # Plot stuff
            plt.plot(r,v)
            plt.ylim(-1.0,0.6)
            plt.grid()
            plt.xlabel(x_label)
            plt.ylabel(y_label)
            plt.show() 
            plt.savefig("lj.png")
        
        elif type_pot == "HB":
            # Import specific library
            import hb6 as hb
            
            # Instantiating an object of the PairwisePot() class and assign it to LJ
            HB1 = hb.PairwisePotHB()
            
            # Invoking potential() method using above data as arguments
            _,_,v = HB1.potential(reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n)
            
            # Plot stuff
            plt.plot(r,v)
            plt.ylim(-1.0,0.6)
            plt.grid()
            plt.xlabel(x_label)
            plt.ylabel(y_label)
            plt.show() 
            plt.savefig("hb.png")
            
        elif type_pot == "ALL":
            # Import specific library
            import vdw6 as vd
            
            # Instantiating an object of the PairwisePot() class and assign it to LJ
            LJ = vd.PairwisePot()
            
            # Invoking potential() method using above data as arguments
            _,_,v1 = LJ.potential(4.00,0.150,4.00,0.15,r,6,12)
            
            # Import specific library
            import hb6 as hb
            
            # Instantiating an object of the PairwisePot() class and assign it to LJ
            HB1 = hb.PairwisePotHB()
            
            # Invoking potential() method using above data as arguments
            _,_,v2 = HB1.potential(1.9,5.0,1.9,5.0,r,10,12)
            
            # Electrostatic potential
            q_i = -4 # Dummy positive charge
            q_j = 4  # Dummy negative charge
            v3 = q_i*q_j/(r*self.epsilon0(r))   # Coulomb potential  
            
            # Import library
            import solv6 as s1
            
            # Instantiating an object of the PairwisePotHB() class and assign it to LJ
            Sol1 = s1.PairwisePotSol()
            
            # Get parameters
            vol_i,sol_i,vol_j,sol_j = 22.4493, -0.00162,17.1573,-0.00251
            
            v4 = Sol1.potential(vol_i,sol_i,vol_j,sol_j,r,0,0)
            
            # Plot stuff
            plt.plot(r,v1,label="Dispersion/Repulsion")
            plt.plot(r,v2,label="Hydrogen Bonds")
            plt.plot(r,v3,label="Electrostatics")
            plt.plot(r,v4,label="Desolvatation")
            
            # Positioning the legends
            plt.legend(loc='upper right')

            plt.ylim(-1.0,0.6)
            plt.grid()
            plt.xlabel(x_label)
            plt.ylabel(y_label)
            plt.title("AutoDock 4.1 Force Field")
            plt.show() 
            plt.savefig("all.png")
            

def main():
    
    # Instantiating an object of the InterMol() class and assign it to pot_LJ
    pot = InterMol("AD4.1_bound.dat")
    
    # Invoking read_AD4_bound() method
    par_list = pot.read_AD4_bound()
    
    # Invoking read_PDBQT() method
    lig_list = pot.read_PDBQT("lig.pdbqt")
    
    # Invoking read_PDBQT() method
    receptor_list = pot.read_PDBQT("receptor.pdbqt")
    
    ##########################################################################
    # For van der Waals Interactions
    
    # Invoking intermol_pot_LJ() method
    v_LJ = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,6)
    
    # Show result
    print("V_LJ(r) = %10.3f"%v_LJ,"Kcal/mol") 
    
    ##########################################################################
    # For Hydrogen-bond Interactions
 
    # Invoking intermol_pot_HB() method
    v_HB = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,10)
    
    # Show result
    print("V_HB(r) = %10.3f"%v_HB,"Kcal/mol")   
    
    ##########################################################################
    # For Electrostactic Potential

    # Invoking intermol_pot_Sol() method
    v_Elec = pot.intermol_electro(lig_list,receptor_list)
        
    # Show result
    print("V_Elec(r) = %10.3f"%v_Elec,"Kcal/mol")  
    
    ##########################################################################
    # For Solvatation
            
    # Invoking intermol_pot_Sol() method
    v_Sol = pot.intermol_pot_Sol(par_list,lig_list,receptor_list,12,6)
        
    # Show result
    print("V_Sol(r) = %10.3f"%v_Sol,"Kcal/mol")      
    
    ##########################################################################
    # For plotting (for comparisons sake)
    # You may comment(#) all lines below
    # Define arguments for plot_pot() method
    print("\nPlotting...")
    x_label = "r($\AA$)"        # x-axis label
    y_label = "V(r)(Kcal/mol)"  # y-axis label
    # For LJ
    #type_pot = "LJ"             # Type of potential
    #r_min = 2.8                 # Minimum value for r (interatomic distance) in Angstrom
    #r_max = 10                  # Maximum value for r (interatomic distance) in Angstrom
    #reqm_i  = 3.5               # sum of vdW radii of two like atoms (in Angstrom) (NA atom)
    #epsilon_i = 0.16            # Well depth (in Kcal/mol) (NA atom)
    #reqm_j  = 3.2               # sum of vdW radii of two like atoms (in Angstrom) (OA atom)
    #epsilon_j = 0.20            # Well depth (in Kcal/mol) (OA atom)
    #m = 6                       # Attraction expoent
    #n = 12                      # Repulsion expoent
    # For HB/ALL
    type_pot = "ALL"            # Type of potential
    r_min = 0.2                 # Minimum value for r (interatomic distance) in Angstrom
    r_max = 10                  # Maximum value for r (interatomic distance) in Angstrom
    reqm_i  = 1.9               # H-bond radius (in Angstrom) (NA atom)
    epsilon_i = 5.0             # Well depth of H-bond (in Kcal/mol) (NA atom)
    reqm_j  = 1.9               # H-bond radius (in Angstrom) (NA atom) (OA atom)
    epsilon_j = 5.0             # Well depth of H-bond (in Kcal/mol) (OA atom)
    m = 10                      # Attraction expoent
    n = 12                      # Repulsion expoent
    # Invoking plot_plot() method
    pot.plot_pot(type_pot,x_label,y_label,r_min,r_max,reqm_i,epsilon_i,reqm_j,epsilon_j,m,n)
        
    print("\nDone!")
    
main()
